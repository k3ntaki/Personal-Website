var randomImageList=[];
var scrollTopFirstTop=[];
$(document).ready(function(e) {
	heightGenerator();
    $(".resist-to-scroll").each(function(index, val) {
            scrollTopFirstTop[$(this)]=$(this).offset().top;
        });
	$("div#random-backgound-list").fadeOut(0);
	$("div#random-backgound-list img").each(function(index, element) {
        randomImageList[index]=$(this).attr("src");
    });
	set_random_bg();
    $(window).on("resize",window,function(){
		heightGenerator();
		});
    $(window).on("scroll",function(){
        var scrollTop=$(window).scrollTop();
        $(".resist-to-scroll").each(function(index, val) {
            var devFactor=$(this).attr("class").indexOf("div-");
            devFactor=$(this).attr("class").substr(devFactor+4,2);
            // alert(devFactor);
            var exTop=scrollTopFirstTop[$(this)];
            $(this).css("top",(exTop-scrollTop/devFactor)+"px")
        });
        $(".cu-resist-to-scroll").each(function(index, val) {
            // alert($(this).offset().top);
            var devFactor=$(this).attr("class").indexOf("div-");
            devFactor=$(this).attr("class").substr(devFactor+4,2);
            // alert(devFactor);
            var exTop=$(this).offset().top;
            $(this).css("top",(exTop-scrollTop/devFactor)+"px")
        });
    });
    
});
function heightGenerator(){
	windowHeight=$(window).height();
			$(".WH-full").each(function(index, element) {
                $(this).css("height",windowHeight+"px");
            });
			$(".WH-half").each(function(index, element) {
                $(this).css("height",windowHeight/2+"px");
            });
			$(".WH-3Q").each(function(index, element) {
                $(this).css("height",windowHeight*3/4+"px");
            });
			$(".WH-2T").each(function(index, element) {
                $(this).css("height",windowHeight*2/3+"px");
            });
			$(".WH-1Q").each(function(index, element) {
                $(this).css("height",windowHeight/4+"px");
            });
			$(".WH-1T").each(function(index, element) {
                $(this).css("height",windowHeight/3+"px");
            });
            $(".WH-1T-Min").each(function(index, element) {
                $(this).css("min-height",windowHeight/3+"px");
            });
			$(".heigt-from-sibiling").each(function(index, element) {
                $(this).css("height",$(this).siblings(this).css("height"));
            });
	}
function set_random_bg() {
	$(".random-background").each(function(index, element) {
		randomNo=parseInt(Math.random()*randomImageList.length);
        $(this).css("background-image","url("+randomImageList[randomNo]+")");
    });
	}