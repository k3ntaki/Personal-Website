var MHFonColapse=0;
var MHFonScroll=0;
$(document).ready(function(){
    $("button[data-target='#menuList']").bind('click change',function(){
        if($(this).hasClass('collapsed')){
            MHFonColapse=1;
            $("div#moto-holder").fadeOut(200);  
        }
        else {
            MHFonColapse=0;
            if(MHFonColapse+MHFonScroll==0)
            $("div#moto-holder").fadeIn(200);   
        }
    });
    $(window).resize(function() {
        if($("button#colapseMenuBut").css("display")=="none"){
            MHFonColapse=0;
            if(MHFonColapse+MHFonScroll==0){
                if(MHFonColapse+MHFonScroll==0)
                $("div#moto-holder").fadeIn(200);   
            }
         }
        else if ($("div#menuList").hasClass('in')){
            MHFonColapse=1;
            $("div#moto-holder").fadeOut(0);  
        }
    });
    $(window).on("scroll",function(){
        var windowTop=$(window).scrollTop();
        if (windowTop>80) {
            MHFonScroll=1;
            $("div#moto-holder").fadeOut(200);
            $("nav").css("background-color","rgba(110,50,70,1)");
            $("nav").removeClass('resist-to-scroll');
            $("nav").css("top","0px");
            $("nav").css("border-top","solid 10px rgba(50,50,50,1)");    
        }
        else {
            var navOpacity=windowTop/80;
            $("nav").css("background-color","rgba(110,50,70,"+navOpacity+")");
            MHFonScroll=0;
            if(MHFonColapse+MHFonScroll==0)
            $("div#moto-holder").fadeIn(200);
            // $("nav").css("top","10px");
            $("nav").addClass('resist-to-scroll');
            $("nav").css("border-top","none");


        } 
    });
});